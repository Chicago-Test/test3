#include <sys/types.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <ctype.h>


#include <windows.h> //for WideCharToMultiByte()
#include <stdbool.h>
#include <locale.h>
#include <stringapiset.h>
#include "xdiff.h"

void usage(char const* prg) {

	fprintf(stderr,
		"use (Myers?): %s -d full-path-from-file  full-path-to-file\n"
		"use (minimal): %s -m full-path-from-file  full-path-to-file\n",
		"use (patience): %s -p full-path-from-file  full-path-to-file\n"
		"use (histogram): %s -h full-path-from-file  full-path-to-file\n",
		prg,prg,prg,prg);
}
static int xdlt_outf(void* priv, mmbuffer_t* mb, int nbuf) {
	int i;

	//printf("%d\n", nbuf); // nbuf=1:Hunk header, nbuf=2 '+' or '-'. nbuf=3 "no new line"

	for (i = 0; i < nbuf; i++) {
		// wchar_t* to UTF-8 (char*)
		int size_needed = WideCharToMultiByte(CP_UTF8, 0, mb[i].ptr, mb[i].size, NULL, 0, NULL, NULL);
		char* strTo = malloc(size_needed*sizeof(char));
		WideCharToMultiByte(CP_UTF8, 0, mb[i].ptr, -1, strTo, size_needed, NULL, NULL);
		if (!fwrite(strTo, size_needed, 1, (FILE*)priv)) {
			return -1;
		}

		//if (!fwrite(mb[i].ptr, mb[i].size, 1, (FILE*)priv)){
		//if (!fwrite(mb[i].ptr, mb[i].size, sizeof(wchar_t), (FILE*)priv)) {
		//	return -1;
		//}
	}


	//wchar_t utf16str[] = L"befor";// L"�ϊ��O�̃e�L�X�g";
	//// �ϊ����char�z��̗v�f��(null�I�[���܂�)���擾
	//int size = WideCharToMultiByte(CP_UTF8, 0, utf16str, -1, NULL, 0, NULL, NULL);
	//char* utf8str = (char *)malloc(size * sizeof(char));
	//// �ϊ�
	//WideCharToMultiByte(CP_UTF8, 0, utf16str, -1, utf8str, size, NULL, NULL);



	return 0;
}
/////////////////////////////////////////////////////////////////////
//https://github.com/jakebailey/git-for-windows/blob/main/xdiff-interface.h
//https://github.com/jakebailey/git-for-windows/blob/main/strbuf.h
typedef int (*xdiff_emit_line_fn)(void*, char*, unsigned long);
typedef void (*xdiff_emit_hunk_fn)(void* data,
	long old_begin, long old_nr,
	long new_begin, long new_nr,
	const char* func, long funclen);
struct strbuf {
	size_t alloc;
	size_t len;
	char* buf;
};
struct xdiff_emit_state {
	xdiff_emit_hunk_fn hunk_fn;
	xdiff_emit_line_fn line_fn;
	void* consume_callback_data;
	struct strbuf remainder;
};
static int xdiff_out_hunk(void* priv_,
	long old_begin, long old_nr,
	long new_begin, long new_nr,
	const char* func, long funclen)
{
	struct xdiff_emit_state* priv = priv_;
	if (priv->remainder.len) {
		//BUG("xdiff emitted hunk in the middle of a line");
		//printf("xdiff emitted hunk in the middle of a line");
	}
	priv->hunk_fn(priv->consume_callback_data,
		old_begin, old_nr, new_begin, new_nr,
		func, funclen);
	return 0;
}
/////////////////////////////////////////////////////////////////////
static int load_mmfile(mmfile_t* mf_ptr, FILE* file, size_t sz)
{
	//if (!(mf_ptr->ptr = malloc(sz)))
	if (!(mf_ptr->ptr = (wchar_t*)malloc(sz* sizeof(wchar_t))))
		return -errno;
	//if (fread(mf_ptr->ptr, sz, 1, file) < 1)
	if (fread(mf_ptr->ptr, sz, sizeof(wchar_t), file) < 1)
		return -errno;
	mf_ptr->size = sz;
	return 0;
}


int main(int argc, char* argv[])
{
	// For windows file (0x0D0A), "No newline at end of file" message is always shown, which is not correct...
	int i = 1;
	long ctxlen = 1<<25; // Show neighbor lines as context. Default 3; Set large number to show all lines 1<<25=33554432
	int bsize = 16, do_diff = 1, do_patch = 0, do_bdiff = 0, do_bpatch = 0, do_rabdiff = 0;
	//memallocator_t malt;
	mmfile_t mf1, mf2;
	xpparam_t xpp;
	xdemitconf_t xecfg;
	bdiffparam_t bdp;
	xdemitcb_t ecb, rjecb;

	//setlocale(LC_ALL, "C.UTF-8");

	char* param1,*file1,*file2;
	//char* file1;
	//char* file2;
	char str0[] = "-d";
	char str1[] = "E:\\temp\\LibXDiff-call\\SampleInputs\\cloc-1.84.pl";
	char str2[] = "E:\\temp\\LibXDiff-call\\SampleInputs\\cloc-2.06.pl";
	//char str1[] = "E:\\temp\\perl_VSCode\\cloc-1.64.pl";
	//char str2[] = "E:\\temp\\perl_VSCode\\cloc-2.08.pl";
	param1 = str0;
	file1 = str1;
	file2 = str2;

	if (IsDebuggerPresent() == false)
	{
		if (argc < 4) {
			usage(argv[0]);
			return 1;
		}
		param1 = argv[1];
		file1 = argv[2];
		file2 = argv[3];
	}

	boolean OUTPUT_TO_FILE = true;
	FILE* outFile1=NULL;
	if (OUTPUT_TO_FILE) {
		outFile1 = fopen("datafasfsa.txt", "wb, ccs=UTF-8");
		ecb.priv = outFile1;
	}
	else {
		ecb.priv = stdout;
	}
	ecb.out_line = xdlt_outf;

	ecb.out_hunk = NULL; // not sure what to input
	//ecb.out_hunk = xdiff_out_hunk;

	memset(&xpp, 0, sizeof(xpp));
	xpp.flags = 0;
	//xpp.flags = XDL_EMIT_FUNCCONTEXT;
	//xpp.flags = XDL_EMIT_FUNCNAMES;
	if (!_stricmp(param1, "-p")) {
		//printf("patience");
		xpp.flags = XDF_PATIENCE_DIFF;
	}
	else if (!_stricmp(param1, "-h")) {
		xpp.flags = XDF_HISTOGRAM_DIFF;
	}
	else if (!_stricmp(param1, "-m")) {
		xpp.flags = XDF_NEED_MINIMAL;
	}

	//if (diff_flags & DIFF_IWHITE) xpp.flags |= XDF_IGNORE_WHITESPACE;

	memset(&xecfg, 0, sizeof(xecfg));
	xecfg.ctxlen = ctxlen;
	
	bdp.bsize = bsize;
	//xdlt_load_mmfile("e:\aaa.txt", &mf1, do_bdiff || do_bpatch);

	FILE* pFile1,*pFile2;
	//FILE* pFile2;
	long sz = 0;
//------------------
	//pFile1 = fopen("E:\\temp\\LibXDiff-source\\x64\\Debug\\a.txt", "rt, ccs=UTF-8");
	pFile1 = fopen(file1, "rt, ccs=UTF-8");
	//pFile1 = fopen(file1, "rb, ccs=UTF-8");
	if (pFile1 == NULL) {
		perror("Error opening file");
		exit(1);
	}
	else {
		fseek(pFile1, 0, SEEK_END);
		sz = ftell(pFile1);
		fseek(pFile1, 0, SEEK_SET); //reset the pointer to the start of the file
	}
	load_mmfile(&mf1, pFile1, sz);
	//------------------
	//pFile2 = fopen("E:\\temp\\LibXDiff-source\\x64\\Debug\\b.txt", "rt, ccs=UTF-8");
	pFile2 = fopen(file2, "rt, ccs=UTF-8");
	//pFile2 = fopen(file2, "rb, ccs=UTF-8");
	if (pFile2 == NULL) {
		perror("Error opening file");
		exit(1);
	}
	else {
		fseek(pFile2, 0, SEEK_END);
		sz = ftell(pFile2);
		fseek(pFile2, 0, SEEK_SET); //reset the pointer to the start of the file
	}
	load_mmfile(&mf2, pFile2, sz);
	//------------------

	xdl_diff(&mf1, &mf2, &xpp, &xecfg, &ecb);
	fclose(pFile1);
	fclose(pFile2);

	if (OUTPUT_TO_FILE) { fclose(outFile1); }
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
