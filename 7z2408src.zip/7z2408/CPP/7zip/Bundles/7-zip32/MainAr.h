#if !defined(MAINFUNC_H)
#define MAINFUNC_H

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

UINT _stdcall Main(LPVOID lpParameter);
int SendCommand7zip();

#endif // !defined(MAINFUNC_H)
