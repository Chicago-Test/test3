//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by 7zTest.rc
//
#define IDD_MY7ZTEST_DIALOG             102
#define IDR_MAINFRAME                   128
#define IDC_INPUT                       1000
#define IDE_OUTPUT                      1001
#define IDL_LIST                        1002
#define IDC_COMMAND                     1003
#define IDC_OPEN_ARCHIVE                1004
#define IDS_RESULT                      1005
#define IDC_FIND_FIRST                  1006
#define IDC_FIND_NEXT                   1007
#define IDC_CLOSE_ARCHIVE               1008
#define IDC_GET_FILE_COUNT              1009
#define IDC_QUERY_FUNCTION_LIST         1010
#define IDC_GET_VERSION                 1011
#define IDC_GET_RUNNING                 1012
#define IDC_CONFIG_DIALOG               1013
#define IDC_CHECK_ARCHIVE               1014
#define IDC_GET_ARC_FILE_NAME           1015
#define IDC_GET_ARC_FILE_SIZE           1016
#define IDC_GET_ARC_ORIGINAL_SIZE       1017
#define IDC_GET_ARC_COMPRESSED_SIZE     1018
#define IDC_GET_ARC_RATIO               1019
#define IDC_GET_ARC_DATE                1020
#define IDC_GET_ARC_TIME                1021
#define IDC_GET_ARC_OS_TYPE             1022
#define IDC_IS_SFX_FILE                 1023
#define IDC_GET_FILE_NAME               1024
#define IDC_GET_ORIGINAL_SIZE           1025
#define IDC_GET_COMPRESSED_SIZE         1026
#define IDC_GET_RATIO                   1027
#define IDC_GET_DATE                    1028
#define IDC_GET_TIME                    1029
#define IDC_GET_CRC                     1030
#define IDC_GET_ATTRIBUTE               1031
#define IDC_GET_OS_TYPE                 1032
#define IDC_GET_METHOD                  1033
#define IDC_GET_WRITE_TIME              1034
#define IDC_GET_WRITE_TIME_EX           1035
#define IDC_GET_ARC_WRITE_TIME_EX       1036
#define IDC_GET_ARC_CREATE_TIME_EX      1037
#define IDC_GET_ARC_ACCESS_TIME_EX      1038
#define IDC_DLL_LIST                    1039
#define IDC_SET_OWNER_WINDOW            1040
#define IDC_CLEAR_OWNER_WINDOW          1041
#define IDC_SET_OWNER_WINDOW_EX         1042
#define IDC_KILL_OWNER_WINDOW_EX        1043
#define IDC_GET_SUB_VERSION             1044
#define IDC_GET_ARC_FILE_SIZE_EX        1045
#define IDC_GET_ARC_ORIGINAL_SIZE_EX    1046
#define IDC_GET_ARC_COMPRESSED_SIZE_EX  1047
#define IDC_GET_ORIGINAL_SIZE_EX        1048
#define IDC_GET_COMPRESSED_SIZE_EX      1049
#define IDC_GET_CREATE_TIME             1050
#define IDC_GET_ACCESS_TIME             1051
#define IDC_GET_ARCHIVE_TYPE            1052
#define IDC_SET_OWNER_WINDOW_EX64       1053
#define IDC_KILL_OWNER_WINDOW_EX64      1054
#define IDC_GET_CREATE_TIME_EX          1055
#define IDC_SET_UNICODE_MODE            1056
#define IDC_GET_ACCESS_TIME_EX          1057
#define IDC_SET_DEFAULT_PASSWORD        1058
#define IDC_GET_DEFAULT_PASSWORD        1059
#define IDC_PASSWORD_DIALOG             1060
#define IDC_API                         1061
#define IDC_SET_PRIORYTY                1062
#define IDC_SFX_CONFIG_DIALOG           1063
#define IDC_SFX_FILE_STORING            1064
#define IDC_GET_LAST_ERROR              1065

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1064
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
