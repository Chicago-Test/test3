// stdafx.h : include file for standard system include files,

#ifndef __STDAFX_H
#define __STDAFX_H

#include "../../../Common/Common.h"

#endif 
