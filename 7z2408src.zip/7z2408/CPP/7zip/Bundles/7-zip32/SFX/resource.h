//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by resource.rc
//
#define IDS_CANT_LOAD_CONFIG_INFO       1
#define IDS_CONFIG_FAILED               2
#define IDS_CANT_CREATE_TEMP_FOLDER     3
#define IDS_EXTRACT_FRIENDLY_NAME       4
#define IDS_EXTRACT_INSTALL_PROMPT      5
#define IDS_EXTRACTION_ERROR_MESSAGE    6
#define IDS_EXTRACTION_ERROR_TITLE      7
#define IDS_CANT_LOAD_CODECS            8
#define IDS_CANT_OPEN_FILE              9
#define IDS_CANT_FIND_SETUP             10
#define IDS_CANT_DELETE_FILE            16
#define IDS_CANT_OPEN_OUTPUT_FILE       17
#define IDS_UNSUPPORTED_METHOD          18
#define IDS_SELECT_FOLDER_TITLE         32
#define IDS_CANT_FIND_ARCHIVE           33
#define IDS_CANT_OPNE_ARCHIVE           34
#define IDS_CANNOT_CREATE_FOLDER        35
#define IDS_PROGRESS_EXTRACTING         36
#define IDS_CONFIRM_CANSEL              48
#define IDI_ICON                        159
#define IDD_DIALOG_PROGRESS             160
#define IDD_DIALOG_EXTRACT              163
#define IDC_PROGRESS1                   1000
#define IDC_EXTRACT_COMBO_PATH          1044
#define IDC_EXTRACT_BUTTON_SET_PATH     1045
#define IDC_STATIC_EXTRACT_EXTRACT_TO   1092

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        166
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1091
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
