$jsonString = (Invoke-webrequest -URI "https://www.reddit.com/r/motorola/comments/1q6319q/motorola_finally_did_it/.json").Content
# Convert the JSON string to PowerShell objects
$posts = $jsonString | ConvertFrom-Json

# Access the title of the first post directly
$firstPostTitle = $posts[0].data.children.data.title
Write-Host "The first post's title is:  $firstPostTitle"
Write-Host  $posts[0].data.children.data.selftext

$posts[1].data.children.Count
$posts[1].data.children[1].data.name
$posts[1].data.children[1].data.body #body_html

# sw.WriteLine(@"<!DOCTYPE HTML PUBLIC ""-//W3C//DTD HTML 4.0 Transitional//EN""><html><head><meta http-equiv=""Content-Type"" content=""text/html; charset=UTF-8""></head><body>");
# sw.WriteLine(Post.Title); sw.WriteLine("<br>"); sw.WriteLine();
# sw.WriteLine(str);
# sw.WriteLine("</body></html>");

Write-Host $firstPostTitle
Write-Host "There are " + $posts[1].data.children.Count + " comments:"
# outString = Post.Listing.SelfText + "<br>" + "\n";


# The result is an array of objects, so we can loop through them
foreach ($post in $posts[1].data.children) {
    Write-Host  "[" ([DateTimeOffset]::FromUnixTimeSeconds($($post.data.created))).LocalDateTime.ToString("yyyy-MM-dd HH:MM:SS") "]"
    Write-Host "Name: $($post.data.author)"
    Write-Host "$($post.data.body)"
    Write-Host "---"
}


Pause
